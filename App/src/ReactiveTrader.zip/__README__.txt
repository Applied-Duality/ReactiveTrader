______                _   _             _____             _           
| ___ \              | | (_)           |_   _|           | |          
| |_/ /___  __ _  ___| |_ ___   _____    | |_ __ __ _  __| | ___ _ __ 
|    // _ \/ _` |/ __| __| \ \ / / _ \   | | '__/ _` |/ _` |/ _ \ '__|
| |\ \  __/ (_| | (__| |_| |\ V /  __/   | | | | (_| | (_| |  __/ |   
\_| \_\___|\__,_|\___|\__|_| \_/ \___|   \_/_|  \__,_|\__,_|\___|_|   
                                                                      
                                                                      

System requirements
-------------------

Reactive Trader requires Microsoft .NET Framework 4.5
You can download it directly from Microsoft: http://www.microsoft.com/en-gb/download/details.aspx?id=30653

Launching Reactive Trader
-------------------------

This zip files contains a .bat file that you can use to launch both the client UI and the server Admin UI: launch '__LaunchReactiveTrader__.bat' to start.